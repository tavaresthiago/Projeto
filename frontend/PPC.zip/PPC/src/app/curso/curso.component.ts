import { Component, OnInit } from '@angular/core';
import {Curso} from "../curso";

import {CURSOS} from "../mock-cursos";

@Component({
  selector: 'app-curso',
  templateUrl: './curso.component.html',
  styleUrls: ['./curso.component.css']
})
export class CursoComponent implements OnInit {

  cursos = CURSOS;

  selecionaCurso: Curso;

  constructor() { }

  ngOnInit() {
  }

  onSelect(curso: Curso): void{
    this.selecionaCurso = curso;
  }

}
