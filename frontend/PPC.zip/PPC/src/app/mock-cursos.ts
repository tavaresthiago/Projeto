import {Curso} from "./curso";

export const CURSOS: Curso[] = [
  {id:1,name: 'ADS'},
  {id:2,name: 'Engenharia Civil'},
  {id:3,name: 'Direito'},
  {id:4,name: 'Educação Fisica'},
  {id:5,name: 'Engenharia Mecanica'}
];
