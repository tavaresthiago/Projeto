import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalhamentoCursoComponent } from './detalhamento-curso.component';

describe('DetalhamentoCursoComponent', () => {
  let component: DetalhamentoCursoComponent;
  let fixture: ComponentFixture<DetalhamentoCursoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalhamentoCursoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalhamentoCursoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
