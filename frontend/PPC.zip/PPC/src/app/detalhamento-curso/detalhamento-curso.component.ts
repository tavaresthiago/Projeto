import { Component, OnInit, Input } from '@angular/core';
import {Curso} from "../curso";

@Component({
  selector: 'app-detalhamento-curso',
  templateUrl: './detalhamento-curso.component.html',
  styleUrls: ['./detalhamento-curso.component.css']
})
export class DetalhamentoCursoComponent implements OnInit {

  @Input() curso: Curso;

  constructor() { }

  ngOnInit() {
  }

}
