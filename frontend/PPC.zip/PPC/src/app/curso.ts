export class Curso {
  id: number;
  name: string;
}
