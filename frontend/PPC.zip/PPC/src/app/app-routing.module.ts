import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
import {RouterModule, Routes} from "@angular/router";

import {CursoComponent} from "./curso/curso.component";
import {DetalhamentoCursoComponent} from "./detalhamento-curso/detalhamento-curso.component";

const routes: Routes = [
  //{ path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  //{ path: 'dashboard', component: DashboardComponent },
  { path: 'detalhamentoCurso/:id', component: DetalhamentoCursoComponent },
  { path: 'curso', component: CursoComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
